from fastapi import FastAPI, Query
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import pandas as pd
import numpy as np
import yfinance as yf
import math

app = FastAPI(title="EGX Stock Analyzer")
app.mount("/static", StaticFiles(directory="static"), name="static")

def rsi(s, n=14):
    d=s.diff()
    gain=d.clip(lower=0).rolling(n).mean()
    loss=(-d.clip(upper=0)).rolling(n).mean()
    rs=gain/loss.replace(0,np.nan)
    return 100-(100/(1+rs))

def atr(df, n=14):
    pc=df["Close"].shift(1)
    tr=pd.concat([(df["High"]-df["Low"]), (df["High"]-pc).abs(), (df["Low"]-pc).abs()],axis=1).max(axis=1)
    return tr.rolling(n).mean()

def fib_levels(df, lookback=120):
    x=df.tail(lookback)
    hi=float(x["High"].max()); lo=float(x["Low"].min())
    rng=hi-lo
    return {
        "high":hi,"low":lo,
        "23.6":hi-rng*.236,"38.2":hi-rng*.382,
        "50.0":hi-rng*.5,"61.8":hi-rng*.618,"78.6":hi-rng*.786,
        "127.2":hi+rng*.272,"161.8":hi+rng*.618
    }

def analyze(symbol):
    symbol=symbol.upper().strip()
    ticker=symbol if "." in symbol else symbol+".CA"
    t=yf.Ticker(ticker)
    df=t.history(period="1y", interval="1d", auto_adjust=False)
    if df.empty:
        raise ValueError(f"لم أجد بيانات للسهم {symbol}. جرّب كود EGX مثل COMI أو SWDY.")

    df=df.dropna(subset=["Close","High","Low","Volume"]).copy()
    close=df["Close"]
    df["EMA20"]=close.ewm(span=20,adjust=False).mean()
    df["EMA50"]=close.ewm(span=50,adjust=False).mean()
    df["EMA200"]=close.ewm(span=200,adjust=False).mean()
    df["RSI"]=rsi(close)
    df["ATR"]=atr(df)
    ema12=close.ewm(span=12,adjust=False).mean()
    ema26=close.ewm(span=26,adjust=False).mean()
    df["MACD"]=ema12-ema26
    df["Signal"]=df["MACD"].ewm(span=9,adjust=False).mean()
    df["VolAvg20"]=df["Volume"].rolling(20).mean()
    df["OBV"]=(np.sign(close.diff()).fillna(0)*df["Volume"]).cumsum()

    last=df.iloc[-1]
    price=float(last["Close"])
    vol=float(last["Volume"])
    volavg=float(last["VolAvg20"]) if pd.notna(last["VolAvg20"]) else vol
    rsi_v=float(last["RSI"]) if pd.notna(last["RSI"]) else 50
    atr_v=float(last["ATR"]) if pd.notna(last["ATR"]) else price*.03

    trend_points=0
    trend_points += 25 if price>last["EMA20"] else 0
    trend_points += 25 if price>last["EMA50"] else 0
    trend_points += 25 if price>last["EMA200"] else 0
    trend_points += 25 if last["MACD"]>last["Signal"] else 0

    if trend_points>=75: trend="صاعد"
    elif trend_points<=25: trend="هابط"
    else: trend="عرضي"

    if rsi_v>=70: saturation="تشبع شرائي"
    elif rsi_v<=30: saturation="تشبع بيعي"
    else: saturation="طبيعي"

    vol_ratio=vol/volavg if volavg else 1
    if vol_ratio>=1.8: volume_state="مرتفع جدًا"
    elif vol_ratio>=1.2: volume_state="مرتفع"
    elif vol_ratio<=0.7: volume_state="ضعيف"
    else: volume_state="طبيعي"

    # "real/fake" is deliberately phrased as confirmation quality, not proof of manipulation.
    if price>last["EMA20"] and vol_ratio>=1.2:
        flow="حركة سعرية مؤكدة نسبيًا بالحجم"
    elif price>last["EMA20"] and vol_ratio<0.8:
        flow="ارتفاع يحتاج تأكيدًا إضافيًا من الحجم"
    elif price<last["EMA20"] and vol_ratio>=1.2:
        flow="ضغط بيعي مؤكد نسبيًا بالحجم"
    else:
        flow="لا توجد إشارة حجم حاسمة"

    fib=fib_levels(df)
    supports=sorted([v for k,v in fib.items() if k in ["38.2","50.0","61.8"] and v<price], reverse=True)
    resistances=sorted([v for k,v in fib.items() if k in ["23.6","38.2","50.0","61.8","78.6"] and v>price])
    support=supports[0] if supports else float(df["Low"].tail(20).min())
    resistance=resistances[0] if resistances else float(df["High"].tail(20).max())
    stop=max(0, support-0.8*atr_v)
    t1=resistance
    t2=price+2*(price-stop)
    t3=price+3*(price-stop)

    dates=[str(x.date()) for x in df.index[-180:]]
    chart=[]
    for d,row in df.tail(180).iterrows():
        chart.append({
            "date":str(d.date()),"open":float(row["Open"]),"high":float(row["High"]),
            "low":float(row["Low"]),"close":float(row["Close"]),"volume":float(row["Volume"])
        })

    fundamentals={}
    try:
        info=t.info
        for key,label in [("marketCap","القيمة السوقية"),("trailingPE","P/E"),("priceToBook","P/B"),
                          ("returnOnEquity","ROE"),("returnOnAssets","ROA"),("dividendYield","Dividend Yield")]:
            val=info.get(key)
            if val is not None:
                fundamentals[label]=val
    except Exception:
        pass

    return {
        "symbol":symbol,"provider_symbol":ticker,"price":price,
        "change_pct":float((price/float(df["Close"].iloc[-2])-1)*100) if len(df)>1 else 0,
        "trend":trend,"trend_score":trend_points,"rsi":rsi_v,
        "saturation":saturation,"volume":vol,"volume_avg":volavg,
        "volume_ratio":vol_ratio,"volume_state":volume_state,"flow":flow,
        "support":support,"resistance":resistance,"stop":stop,
        "targets":[t1,t2,t3],"fib":fib,"fundamentals":fundamentals,
        "chart":chart,
        "note":"هذا نموذج تحليلي تعليمي، وليس توصية استثمارية. جودة بيانات EGX اللحظية تعتمد على مزود البيانات المستخدم."
    }

@app.get("/")
def home():
    return FileResponse("static/index.html")

@app.get("/api/analyze")
def api_analyze(symbol: str = Query(..., min_length=1)):
    try:
        return JSONResponse(analyze(symbol))
    except Exception as e:
        return JSONResponse({"error":str(e)}, status_code=400)
