# EGX Stock Analyzer — Build APK via GitHub

1. Create a new GitHub repository.
2. Upload the contents of this folder.
3. Open the **Actions** tab.
4. Select **Build Android APK** and run it (or push to main/master).
5. When the workflow finishes, open the run and download the artifact:
   `EGX-Stock-Analyzer-debug-apk`
6. Extract it on your phone and install `app-debug.apk`.

Important:
- The APK wraps the current mobile web UI.
- The analysis API still needs the backend (`app.py`) to be hosted on a reachable server.
- The current project is an MVP; for production EGX data, connect a reliable/licensed market-data provider.
