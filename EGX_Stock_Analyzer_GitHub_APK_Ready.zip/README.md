# EGX Stock Analyzer — MVP

نسخة أولية قابلة للتشغيل محليًا لتحليل أسهم البورصة المصرية.

## التشغيل

Python 3.10+:

```bash
pip install -r requirements.txt
uvicorn app:app --reload
```

ثم افتح:
http://127.0.0.1:8000

اكتب كود EGX مثل:
COMI
SWDY
TMGH

## ماذا تفعل النسخة الحالية؟
- جلب تاريخ يومي عبر Yahoo Finance باستخدام رمز EGX مثل COMI.CA
- السعر والتغير
- EMA20/50/200
- RSI
- MACD
- ATR
- Volume مقابل متوسط 20 جلسة
- تقييم تأكيد الحركة بالحجم
- دعم/مقاومة مبدئيان
- Fibonacci
- 3 مستهدفات ووقف خسارة مبدئي
- بعض المؤشرات الأساسية إذا وفرها مزود البيانات

## الخطوة التالية للإنتاج
للنسخة الاحترافية، يُستبدل مصدر البيانات العام بمزود EGX موثوق/مرخّص للبيانات اللحظية وLevel 2، ثم نضيف:
- Market Depth وTrades لحظيًا
- Accumulation/Distribution وVWAP وOBV متقدم
- تحليل الصفقات الكبيرة
- بيانات مالية ربع سنوية وسنوية
- مقارنة القطاع
- Backtesting
- تنبيهات
- حسابات مستخدمين
- Watchlist
- API caching وPostgreSQL
