# EGX Stock Analyzer — Mobile PWA

هذه نسخة Mobile-first ويمكن تثبيتها على الهاتف كتطبيق PWA.

## تشغيل السيرفر
```bash
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000
```

من الهاتف افتح عنوان السيرفر على نفس الشبكة، أو انشر المشروع على استضافة تدعم HTTPS.
بعد فتح الموقع من Chrome/المتصفح اختر "Add to Home screen" / "تثبيت التطبيق".

## ملاحظة
هذه النسخة ما زالت MVP. بيانات EGX اللحظية وعمق السوق تحتاج مزود بيانات مناسب.
